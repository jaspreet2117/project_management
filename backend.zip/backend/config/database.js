const { Sequelize } = require('sequelize');

const sequelize = new Sequelize('pms', 'root', '', {
  host: 'localhost',
  dialect: 'mysql',
});

module.exports = sequelize;
