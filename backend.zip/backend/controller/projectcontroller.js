const Project = require('../models/projects');

exports.createProject = async (req, res) => {
  try {
    // Ensure all expected fields are destructured from req.body
    const { name, image, description, created_by, status, deadline, priority, team_member, progress } = req.body;

    if (!name || !created_by) {
      return res.status(400).json({ message: 'Name and created_by are required.' });
    }

    const newProject = await Project.create({
      name: name,
      image: image,
      description: description,
      created_by: created_by, // Use the passed created_by, not hardcoded "2"
      status: status,
      deadline: deadline,
      priority: priority,
      progress: progress,
      team_member: team_member, // Consistently use team_member
    });

    res.status(201).json({
      message: 'Project created successfully!',
      project: newProject // Send back the created project
    });
  } catch (err) {
    console.error('Create project error:', err);
    res.status(500).json({ error: 'Failed to create project.' });
  }
};
exports.getAllProjects = async (req, res) => {

  try {
    const projects = await Project.findAll();
    res.json(projects);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch projects', error: err.message });
  }
};

// Get one
// exports.getProjectById = async (req, res) => {
//   try {
//     const project = await Project.findByPk(req.params.id);
//     if (!project) return res.status(404).json({ message: 'Project not found' });
//     res.json(project);
//   } catch (err) {
//     res.status(500).json({ message: 'Failed to fetch project', error: err.message });
//   }
// };

// Update
exports.updateProject = async (req, res) => {
  try {
    const updated = await Project.update(req.body, { where: { project_id: req.params.id } });
    res.json({ message: 'Project updated', updated });
  } catch (err) {
    res.status(500).json({ message: 'Failed to update project', error: err.message });
  }
};

// Delete
exports.deleteProject = async (req, res) => {
  try {
    const deleted = await Project.destroy({ where: { project_id: req.params.id } });
    if (!deleted) return res.status(404).json({ message: 'Project not found' });
    res.json({ message: 'Project deleted' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to delete project', error: err.message });
  }
};

