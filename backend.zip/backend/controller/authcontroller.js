const bcrypt = require('bcryptjs');
const User = require('../models/user');
const jwt = require('jsonwebtoken');
const SECRET_KEY = 'projectmanagementsystem2117';

// Login API
const login = async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ message: 'Email and password are required', success: false });
  }

  try {
    const user = await User.findOne({ where: { email } });

    if (!user) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }
    // Check hashed passwords

    const isMatch = await bcrypt.compare(password, user.password);

    if (!isMatch) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }
    //  Generate JWT token
    const token = jwt.sign(
      { id: user.id, email: user.email, name: user.name },
      SECRET_KEY,
      { expiresIn: '1h' }
    );


    res.json({
      message: 'Login successful',
      success: true,
      token,
      user: { id: user.id, name: user.name, email: user.email }
    });

  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

// register api
const register = async (req, res) => {
  const { name, email, password } = req.body;

  //Name validations
  if (!name || name.trim() === "") {
    return res.status(400).json({ message: "Name is required." });
  }

  if (typeof name !== "string") {
    return res.status(400).json({ message: "Name must be a string." });
  }

  if (name.length < 3) {
    return res.status(400).json({ message: "Name must be at least 3 characters." });
  }

  if (name.length > 50) {
    return res.status(400).json({ message: "Name must not exceed 50 characters." });
  }

  const nameRegex = /^[a-zA-Z ]+$/;
  if (!nameRegex.test(name)) {
    return res.status(400).json({ message: "Name can only contain letters and spaces." });
  }

  try {
    // Check if user already exists
    const existingUser = await User.findOne({ where: { email } });
    if (existingUser) {
      return res.status(400).json({ message: 'Email already registered.' });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create user
    const newUser = await User.create({
      name,
      email,
      password: hashedPassword
    });

    res.status(201).json({ message: 'User registered successfully.' });
  } catch (error) {
    console.error('Registration Error:', error);
    res.status(500).json({ message: 'Server error.', res });
  }
};
const forget = async (req, res) => {
  const { name, email, password } = req.body;

  try {
    const user = await User.findOne({ where: { name, email } });
    if (!user) {
      return res.status(401).json({ success: false, message: 'Invalid email or user name' });
    }
    if (!password) {
      return res.status(200).json({ success: true, message: 'User verified' });
    }

    // Step 2: Reset password
    const hashedPassword = await bcrypt.hash(password, 10);
    await User.update({ password: hashedPassword }, { where: { id: user.id } });

    return res.json({
      success: true,
      message: 'Password reset successfully',
      user: { id: user.id, name: user.name },
    });

  } catch (err) {
    return res.status(500).json({ success: false, message: 'Failed to reset password' });
  }

};

module.exports = {
  login, register, forget
};