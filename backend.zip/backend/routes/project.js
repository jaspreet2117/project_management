const express = require('express');
const router = express.Router();
const projectController = require('../controller/projectcontroller');

router.post('/add', projectController.createProject);
router.get('/all', projectController.getAllProjects);
// router.get('/:id', projectController.getProjectById);
router.put('/:id', projectController.updateProject);
router.delete('/:id', projectController.deleteProject);


module.exports = router;
