var express = require('express');
var router = express.Router();
const { login, register,forget } = require('../controller/authcontroller');
// Google login route
// router.post('/google-login', userController.googleLogin);

// Email/password login route
router.post('/login',login);

// registor route
router.post('/register',register);
// forget password
router.post('/forget',forget)

module.exports = router;
