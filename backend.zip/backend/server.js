const express = require('express');
const app = express();
const sequelize = require('./config/database');
const User = require('./models/user');
const cors=require('cors')

app.use(express.json());
app.use(cors());
const port = 3000;

// Sync Sequelize models (create tables if not exist)
sequelize.sync()
  .then(() => console.log('Database synced'))
  .catch(err => console.error('Error syncing database:', err));

// Login endpoint
app.post('/login', async (req, res) => {
  const { email, password } = req.body;
console.log(email);

  try {
    const user = await User.findOne({ where: { email } });

    if (!user) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }
    
    //  simple password check 
    if (user.password !== password) {
      console.log(password);
      return res.status(401).json({ message: 'Invalid email or password' });
      
    }

    res.json({ message: 'Login successful' ,success:true});

  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
