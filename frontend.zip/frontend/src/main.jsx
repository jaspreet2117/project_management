import React from 'react'
import ReactDOM from 'react-dom/client'
import { RouterProvider } from 'react-router-dom'
import { router } from './routes'
import { GoogleOAuthProvider } from '@react-oauth/google';
import './index.css'
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <GoogleOAuthProvider clientId="578758404616-7bjnu7n336gnfkeibk9ime3rqvgpmc52.apps.googleusercontent.com">
      <RouterProvider router={router} />
    </GoogleOAuthProvider>

  </React.StrictMode>
)