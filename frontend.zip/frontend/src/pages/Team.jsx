import React, { useState } from 'react';
import { FiUser, FiMail, FiPhone, FiSettings, FiPlus, FiSearch, FiFilter } from 'react-icons/fi';
import "./Team.css";

const Team = () => {
  // Sample team data
  const [teamMembers, setTeamMembers] = useState([
    {
      id: 1,
      name: 'Sarah Johnson',
      role: 'Frontend Developer',
      email: 'sarah@example.com',
      phone: '(555) 123-4567',
      status: 'active',
      joinDate: '2022-03-15',
      avatar: 'https://randomuser.me/api/portraits/women/44.jpg'
    },
    {
      id: 2,
      name: 'Michael Chen',
      role: 'Backend Developer',
      email: 'michael@example.com',
      phone: '(555) 234-5678',
      status: 'active',
      joinDate: '2021-11-02',
      avatar: 'https://randomuser.me/api/portraits/men/32.jpg'
    },
    {
      id: 3,
      name: 'Emma Davis',
      role: 'UI/UX Designer',
      email: 'emma@example.com',
      phone: '(555) 345-6789',
      status: 'active',
      joinDate: '2023-01-20',
      avatar: 'https://randomuser.me/api/portraits/women/68.jpg'
    },
    {
      id: 4,
      name: 'David Wilson',
      role: 'Project Manager',
      email: 'david@example.com',
      phone: '(555) 456-7890',
      status: 'on leave',
      joinDate: '2020-09-10',
      avatar: 'https://randomuser.me/api/portraits/men/75.jpg'
    },
    {
      id: 5,
      name: 'Jessica Lee',
      role: 'QA Engineer',
      email: 'jessica@example.com',
      phone: '(555) 567-8901',
      status: 'active',
      joinDate: '2023-05-05',
      avatar: 'https://randomuser.me/api/portraits/women/25.jpg'
    }
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  // Filter team members based on search and status
  const filteredMembers = teamMembers.filter(member => {
    const matchesSearch = member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      member.role.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || member.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  // Status colors mapping
  const statusColors = {
    'active': 'bg-success text-white opacity-100', // Full opacity
    'on leave': 'bg-warning text-dark opacity-75', // 75% opacity
    'inactive': 'bg-secondary text-white opacity-50' // 50% opacity
  };


  return (
    <div className="team-container">
      <div className="team-header">
        <div>
          <h1>Team Members</h1>
          <p className="subtitle">Manage your team members and their roles</p>
        </div>
        <button className="add-member-btn">
          <FiPlus className="icon" />
          Add Member
        </button>
      </div>

      {/* Team Stats and Filters */}
      <div className="team-stats-filters">
        <div className="stats-card">
          <div className="stat">
            <h3>Total Members</h3>
            <p className="value">{teamMembers.length}</p>
          </div>
          <div className="stat">
            <h3>Active</h3>
            <p className="value">{teamMembers.filter(m => m.status === 'active').length}</p>
          </div>
          <div className="stat">
            <h3>On Leave</h3>
            <p className="value">{teamMembers.filter(m => m.status === 'on leave').length}</p>
          </div>
        </div>

        <div className="filter-controls">
          <div className="search-box">
            <FiSearch className="search-icon" />
            <input
              type="text"
              placeholder="Search team members..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="status-filter">
            <FiFilter className="filter-icon" />
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <option value="all">All Status</option>
              <option value="active">Active</option>
              <option value="on leave">On Leave</option>
              <option value="inactive">Inactive</option>
            </select>
          </div>
        </div>
      </div>

      {/* Team Members Grid */}
      <div className="team-grid">
        {filteredMembers.map(member => (
          <div className="member-card" key={member.id}>
            <div className="member-header">
              <div className="avatar-container">
                <img src={member.avatar} alt={member.name} className="team-avatar" />
                <span className={`status-dot ${member.status}`}></span>
              </div>
              <div className="member-info">
                <h3 className="member-name">{member.name}</h3>
                <p className="member-role">{member.role}</p>
                <span className={`status-badge ${statusColors[member.status]}`}>
                  {member.status}
                </span>
              </div>
              <button className="settings-btn">
                <FiSettings />
              </button>
            </div>

            <div className="member-details">
              <div className="team-detail-item">
                <FiMail className="detail-icon" />
                <span>{member.email}</span>
              </div>
              <div className="team-detail-item">
                <FiPhone className="detail-icon" />
                <span>{member.phone}</span>
              </div>
              <div className="team-detail-item">
                <FiUser className="detail-icon" />
                <span>Joined {member.joinDate}</span>
              </div>
            </div>

            <div className="member-actions">
              <button className="action-btn messages">Message</button>
              <button className="action-btn view">View Profile</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Team;