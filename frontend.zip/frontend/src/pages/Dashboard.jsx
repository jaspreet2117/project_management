import React, { useRef, useEffect, useState } from 'react';
import { FiTrendingUp,FiTrendingDown, FiUsers, FiDollarSign, FiActivity, FiCalendar, FiBarChart2 } from 'react-icons/fi';
import { Chart, registerables } from 'chart.js';    

// Register Chart.js components
Chart.register(...registerables);

const Dashboard = () => {

  const Project_completedChartRef = useRef(null);
  const activityChartRef = useRef(null);
  let Project_completedChartInstance = null;
  let activityChartInstance = null;

  // State to hold dynamically fetched projects
  const [projects, setProjects] = useState([]);
  // State for managing loading status during API calls
  const [isLoading, setIsLoading] = useState(false);
  // State for displaying user messages (success/error)
  const [userMessage, setUserMessage] = useState({ text: '', type: '' });

  // Recent activities remain static as dynamic data would require a dedicated API endpoint
  const recentActivities = [
    { id: 1, project: "Recipe Finder", action: "was marked as completed", time: "2 days ago" },
    { id: 2, project: "Chat App", action: "progress updated to 60%", time: "3 days ago" },
    { id: 3, project: "Tour and Travels", action: "had team added", time: "5 days ago" },
    { id: 4, project: "Live Streaming App", action: "started development", time: "1 week ago" }
  ];

  // Function to fetch projects from the backend API
  const fetchProjects = async () => {
    setIsLoading(true);
    setUserMessage({ text: '', type: '' });
    try {
      const response = await fetch('http://localhost:3000/project/all');
      const data = await response.json();

      if (response.ok) {
        setProjects(data);
      } else {
        setUserMessage({ text: data.message || 'Failed to fetch projects.', type: 'error' });
      }
    } catch (error) {
      setUserMessage({ text: 'Network error: Could not connect to the server.', type: 'error' });
      console.error('Error fetching dashboard projects:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // useEffect to fetch projects on component mount
  useEffect(() => {
    fetchProjects();
  }, []);

  // Calculate dynamic stats based on fetched projects
  const completedProjectsCount = projects.filter(p => p.status === 'Completed').length;
  const totalProjectsCount = projects.length;
  // Calculate total active team members from projects in 'In Progress' status
  const activeTeamMembersCount = projects.filter(p => p.status === 'In Progress').reduce((sum, p) => sum + (Number(p.team_member) || 0), 0);

  // Dynamic stats array using calculated values
  const dynamicStats = [
    // For these, 'change' and 'trend' are now null as we don't have historical data to show a real trend
    { title: "Projects Completed", value: `${completedProjectsCount}/${totalProjectsCount}`, change: null, icon: <FiDollarSign size={24} />, trend: null },
    { title: "Active Team Members", value: activeTeamMembersCount.toString(), change: null, icon: <FiUsers size={24} />, trend: null },
    { title: "Task Completion Rate", value: "62%", change: "12%", icon: <FiActivity size={24} />, trend: 'up' }, // Static
    { title: "Avg. Progress per Week", value: "5% ", change: "-1.2%", icon: <FiCalendar size={24} />, trend: 'down' } // Static
  ];


  // useEffect to initialize/update charts when projects data changes
  useEffect(() => {
    // Project_completed Chart (Bar)
    if (Project_completedChartRef.current && projects.length > 0) {
      const ctx = Project_completedChartRef.current.getContext('2d');

      // Destroy previous instance if exists
      if (Project_completedChartInstance) {
        Project_completedChartInstance.destroy();
      }

      // Dynamically get project names and progress for the chart
      const projectNames = projects.map(p => p.name);
      const projectProgress = projects.map(p => p.progress || 0); // Default to 0 if progress is null/undefined

      Project_completedChartInstance = new Chart(ctx, {
        type: 'bar',
        data: {
          labels: projectNames, // Dynamic labels
          datasets: [{
            label: 'Completion (%)',
            data: projectProgress, // Dynamic data
            backgroundColor: '#4361ee',
            borderRadius: 6,
            borderSkipped: false,
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              display: false
            }
          },
          scales: {
            y: {
              beginAtZero: true,
              grid: {
                drawBorder: false,
                color: '#e9ecef'
              },
              ticks: {
                callback: function (value) {
                  return value.toLocaleString();
                }
              }
            },
            x: {
              grid: {
                display: false,
                drawBorder: false
              }
            }
          }
        }
      });
    }

    // Activity Chart (Line) - Remains mostly static as there's no dynamic activity data from projects yet
    if (activityChartRef.current) {
      const ctx = activityChartRef.current.getContext('2d');

      // Destroy previous instance if exists
      if (activityChartInstance) {
        activityChartInstance.destroy();
      }

      activityChartInstance = new Chart(ctx, {
        type: 'line',
        data: {
          labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
          datasets: [{
            label: 'Task Completion (%)',
            data: [45, 52, 60, 68, 72, 78, 85],
            borderColor: '#10b981',
            backgroundColor: 'rgba(16, 185, 129, 0.05)',
            borderWidth: 2,
            tension: 0.4,
            fill: true
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              display: false
            }
          },
          scales: {
            y: {
              beginAtZero: true,
              grid: {
                drawBorder: false,
                color: '#e9ecef'
              }
            },
            x: {
              grid: {
                display: false,
                drawBorder: false
              }
            }
          }
        }
      });
    }

    // Cleanup function
    return () => {
      if (Project_completedChartInstance) Project_completedChartInstance.destroy();
      if (activityChartInstance) activityChartInstance.destroy();
    };
  }, [projects]); // Dependency array: re-run effect when 'projects' state changes

  return (
    // Dashboard
    <div className="dashboard-container">
      <div className="dashboard-header">
        <h1>Dashboard Overview</h1>
        <div className="date-filter">
          <span>Last 30 days</span>
          <FiCalendar className="calendar-icon" />
        </div>
      </div>

      {/* Stats Cards */}
      <div className="stats-grid">
        {dynamicStats.map((stat, index) => (
          <div className="stat-card" key={index}>
            <div className="stat-icon" style={{ backgroundColor: stat.trend === 'up' ? '#e6f7ee' : (stat.trend === 'down' ? '#feeceb' : '#e0e0e0') }}> {/* Added default color for null trend */}
              {stat.icon}
            </div>
            <div className="stat-content">
              <h3>{stat.title}</h3>
              <p className="stat-value">{stat.value}</p>
              {/* Conditional rendering for change and trend icon */}
              {stat.change && (
                <p className={`stat-change ${stat.trend}`}>
                  {stat.change} {stat.trend === 'up' && <FiTrendingUp className="trend-icon" />}
                  {stat.trend === 'down' && <FiTrendingDown className="trend-icon" />} {/* Assuming FiTrendingDown for 'down' trend is available/desired */}
                </p>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Charts Row */}
      <div className="charts-row">
        <div className="chart-container">
          <div className="chart-header">
            <h3>Project_completed Overview</h3>
            <FiBarChart2 className="chart-icon" />
          </div>
          <div className="chart-wrapper">
            {isLoading && <p className="text-center" style={{color: '#4361ee'}}>Loading chart data...</p>}
            {userMessage.type === 'error' && <p className="text-center" style={{color: '#dc3545'}}>{userMessage.text}</p>}
            <canvas ref={Project_completedChartRef}></canvas>
          </div>
        </div>

        <div className="chart-container">
          <div className="chart-header">
            <h3>User Activity</h3>
            <FiActivity className="chart-icon" />
          </div>
          <div className="chart-wrapper">
            <canvas ref={activityChartRef}></canvas>
          </div>
        </div>
      </div>

      {/* Bottom Row */}
      <div className="bottom-row">
        <div className="recent-activity">
          <h3>Recent Activity</h3>
          <ul>
            {recentActivities.map(activity => (
              <li key={activity.id}>
                <div className="activity-dot"></div>
                <div className="activity-content">
                  <span className="activity-user">{activity.project}</span>
                  <span className="activity-action">{activity.action}</span>
                  <span className="activity-time">{activity.time}</span>
                </div>
              </li>
            ))}
          </ul>
        </div>

        <div className="project-progress">
          <h3>Project Status</h3>
          {isLoading && <p className="text-center" style={{color: '#4361ee'}}>Loading project statuses...</p>}
          {userMessage.type === 'error' && <p className="text-center" style={{color: '#dc3545'}}>{userMessage.text}</p>}
          
          {/* Conditional rendering for no projects fetched */}
          {!isLoading && projects.length === 0 && userMessage.text === '' && (
            <p className="text-center" style={{color: '#6c757d'}}>No projects available to display status.</p>
          )}

          {projects.map((project, index) => (
            <div className="project-item" key={index}>
              <div className="project-info">
                <h4>{project.name}</h4>
                <span className={`project-status ${project.status}`}>{project.status}</span>
              </div>
              <div className="progress-container">
                {/* <span className="progress-text">{project.progress}%</span> */}
                <div
                  className="progress-bar"
                  style={{ width: `${project.progress || 0}%` }} // Use fetched progress
                ></div>
              </div>
              <div className="project-team">
                <span>{project.team_member || 0} team members</span> {/* Use project.team_member */}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
