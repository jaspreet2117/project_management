import React, { useState } from 'react';
import {
    FiSearch,
    FiMessageSquare,
    FiUser,
    FiPaperclip,
    FiSmile,
    FiSend,
    FiChevronLeft
} from 'react-icons/fi';
import "./Message.css";

const Messages = () => {
    const [activeConversation, setActiveConversation] = useState(null);
    const [newMessage, setNewMessage] = useState('');

    // Sample conversations data
    const conversations = [
        {
            id: 1,
            name: 'Sarah Johnson',
            avatar: 'https://randomuser.me/api/portraits/women/44.jpg',
            lastMessage: 'Hey, just sent you the design files',
            time: '10:30 AM',
            unread: 2
        },
        {
            id: 2,
            name: 'Michael Chen',
            avatar: 'https://randomuser.me/api/portraits/men/32.jpg',
            lastMessage: 'The API documentation is ready for review',
            time: 'Yesterday',
            unread: 0
        },
        {
            id: 3,
            name: 'Emma Davis',
            avatar: 'https://randomuser.me/api/portraits/women/68.jpg',
            lastMessage: 'Can we schedule a meeting for tomorrow?',
            time: 'Yesterday',
            unread: 1
        },
        {
            id: 4,
            name: 'David Wilson',
            avatar: 'https://randomuser.me/api/portraits/men/75.jpg',
            lastMessage: 'The project timeline looks good',
            time: 'Monday',
            unread: 0
        },
        {
            id: 5,
            name: 'Jessica Lee',
            avatar: 'https://randomuser.me/api/portraits/women/25.jpg',
            lastMessage: 'Thanks for the quick response!',
            time: 'Last week',
            unread: 0
        }
    ];

    // Sample messages data
    const messages = {
        1: [
            { id: 1, sender: 'Sarah Johnson', text: 'Hey there!', time: '10:00 AM', isMe: false },
            { id: 2, sender: 'Me', text: 'Hi Sarah! How are you?', time: '10:05 AM', isMe: true },
            { id: 3, sender: 'Sarah Johnson', text: 'I\'m good, thanks! Just wanted to share the design files with you', time: '10:10 AM', isMe: false },
            { id: 4, sender: 'Sarah Johnson', text: 'Here they are: designs-final.zip', time: '10:30 AM', isMe: false }
        ],
        2: [
            { id: 1, sender: 'Michael Chen', text: 'The API documentation is ready for your review', time: '9:00 AM', isMe: false },
            { id: 2, sender: 'Me', text: 'Great, I\'ll check it out this afternoon', time: '9:15 AM', isMe: true }
        ],
        3: [
            { id: 1, sender: 'Emma Davis', text: 'Can we schedule a meeting for tomorrow?', time: '3:45 PM', isMe: false },
            { id: 2, sender: 'Me', text: 'Sure, how about 2 PM?', time: '4:00 PM', isMe: true },
            { id: 3, sender: 'Emma Davis', text: 'That works for me!', time: '4:05 PM', isMe: false }
        ]
    };

    const handleSendMessage = () => {
        if (newMessage.trim() === '') return;

        // In a real app, you would send the message to your backend here
        setNewMessage('');
    };

    return (
        <>
            <div className="messages-container">
                {!activeConversation ? (
                    // Conversation list view
                    <div className="conversation-list">
                        <div className="messages-header">
                            <h1>Messages</h1>
                            <div className="search-bar">
                                <FiSearch className="search-icon" />
                                <input type="text" placeholder="Search conversations..." />
                            </div>
                        </div>

                        <div className="conversations">
                            {conversations.map(conversation => (
                                <div
                                    key={conversation.id}
                                    className="conversation-item"
                                    onClick={() => setActiveConversation(conversation.id)}
                                >
                                    <img src={conversation.avatar} alt={conversation.name} className="avatar" />
                                    <div className="conversation-details">
                                        <div className="conversation-header">
                                            <h3>{conversation.name}</h3>
                                            <span className="time">{conversation.time}</span>
                                        </div>
                                        <p className="last-message">{conversation.lastMessage}</p>
                                    </div>
                                    {conversation.unread > 0 && (
                                        <span className="unread-badge">{conversation.unread}</span>
                                    )}
                                </div>
                            ))}
                        </div>
                    </div>
                ) : (
                    // Single conversation view
                    <div className={`conversation-view ${activeConversation ? 'active' : ''}`}>
                        <div className="conversation-header text-message">
                            <button
                                className="back-button"
                                onClick={() => setActiveConversation(null)}
                            >
                                <FiChevronLeft />
                            </button>
                            <div className="listing-user-info">
                                <img
                                    src={conversations.find(c => c.id === activeConversation).avatar}
                                    alt={conversations.find(c => c.id === activeConversation).name}
                                    className="avatar"
                                />
                                <h2>{conversations.find(c => c.id === activeConversation).name}</h2>
                            </div>
                        </div>

                        <div className="messages-list">
                            {messages[activeConversation]?.map(message => (
                                <div
                                    key={message.id}
                                    className={`message ${message.isMe ? 'sent' : 'received'}`}
                                >
                                    {!message.isMe && (
                                        <img
                                            src={conversations.find(c => c.id === activeConversation).avatar}
                                            alt={message.sender}
                                            className="message-avatar"
                                        />
                                    )}
                                    <div className="message-content">
                                        {!message.isMe && <span className="sender-name">{message.sender}</span>}
                                        <div className="message-bubble">
                                            <p>{message.text}</p>
                                            <span className="message-time">{message.time}</span>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>

                        <div className="message-input">
                            <button className="attachment-button">
                                <FiPaperclip />
                            </button>
                            <input
                                type="text"
                                placeholder="Type a message..."
                                value={newMessage}
                                onChange={(e) => setNewMessage(e.target.value)}
                                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                            />
                            <button className="emoji-button">
                                <FiSmile />
                            </button>
                            <button
                                className="send-button"
                                onClick={handleSendMessage}
                            >
                                <FiSend />
                            </button>
                        </div>
                    </div>
                )}
            </div>
        </>
    );
};

export default Messages;