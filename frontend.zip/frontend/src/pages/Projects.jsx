import React, { useState, useEffect } from 'react';
import { FiFolder, FiUsers, FiClock, FiCheckCircle, FiActivity, FiPlus, FiX } from 'react-icons/fi';
import "./Projects.css"; // Ensure this CSS file is linked and contains the styles

const Projects = () => {
    const [projects, setProjects] = useState([]);
    const [showModal, setShowModal] = useState(false);
    // State for a new project (when adding)
    const [newProject, setNewProject] = useState({
        name: '',
        image: '',
        description: '',
        created_by: '2', // Placeholder, ideally from auth context
        status: 'Not Started', // Default status for new projects
        progress: 0,          // Default progress for new projects
        team_member: 1,              // Default team size for new projects
        deadline: '',         // No default deadline
        priority: 'Medium'    // Default priority
    });
    // State for the project currently being edited. Null means "add" mode.
    const [editingProject, setEditingProject] = useState(null); // Added: New state for editing

    const [isLoading, setIsLoading] = useState(false);
    const [userMessage, setUserMessage] = useState({ text: '', type: '' });

    // Constants for dropdown options
    const statusOptions = ['Not Started', 'In Progress', 'Completed', 'On Hold'];
    const priorityOptions = ['Low', 'Medium', 'High'];

    useEffect(() => {
        fetchProjects();
    }, []);

    const fetchProjects = async () => {
        setIsLoading(true);
        setUserMessage({ text: '', type: '' });
        try {
            const response = await fetch('http://localhost:3000/project/all'); 
            const data = await response.json();

            if (response.ok) {
                setProjects(data);
            } else {
                setUserMessage({ text: data.message || 'Failed to fetch projects.', type: 'error' });
            }
        } catch (error) {
            setUserMessage({ text: 'Network error: Could not connect to the server.', type: 'error' });
            console.error('Error fetching projects:', error);
        } finally {
            setIsLoading(false);
        }
    };

    // Consolidated handler for input changes in both add and edit forms
    const handleInputChange = (e) => {
        const { name, value } = e.target;
        if (editingProject) {
            // If in edit mode, update the editingProject state
            setEditingProject(prevState => ({
                ...prevState,
                [name]: value
            }));
        } else {
            // If in add mode, update the newProject state
            setNewProject(prevState => ({
                ...prevState,
                [name]: value
            }));
        }
    };

    // Handles opening the modal for ADDING a new project
    const handleAddClick = () => {
        setEditingProject(null); // Ensure we are in add mode
        setNewProject({ // Reset new project form fields
            name: '',
            image: '',
            description: '',
            created_by: '2',
            status: 'Not Started',
            progress: 0,
            team: 1,
            deadline: '',
            priority: 'Medium'
        });
        setUserMessage({ text: '', type: '' }); // Clear any previous messages
        setShowModal(true); // Open the modal
    };

    // Handles opening the modal for EDITING an existing project
    const handleEditClick = (project) => {
        setEditingProject(project); // Set the project to be edited
        setNewProject(project); // Pre-fill the form with existing project data
        setUserMessage({ text: '', type: '' }); // Clear any previous messages
        setShowModal(true); // Open the modal
    };

    // Handles closing the modal
    const handleCloseModal = () => {
        setShowModal(false);
        setEditingProject(null); // Reset editing project state
        setNewProject({ // Reset new project form in case it was half-filled
            name: '', image: '', description: '', created_by: '2',
            status: 'Not Started', progress: 0, team: 1, deadline: '', priority: 'Medium'
        });
    };

    // Handles submission for ADDING a new project
    const handleAddProject = async (e) => {
        e.preventDefault();
        setIsLoading(true);
        setUserMessage({ text: '', type: '' });

        try {
            const response = await fetch('http://localhost:3000/project/add', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(newProject)
            });
            const data = await response.json();

            if (response.ok) {
                setUserMessage({ text: data.message || 'Project created successfully!', type: 'success' });

                handleCloseModal(); // Close modal and reset form
                fetchProjects(); // Re-fetch all projects to update the table
            } else {
                setUserMessage({ text: data.message || 'Failed to create project.', type: 'error' });
            }
        } catch (error) {
            setUserMessage({ text: 'Network error: Could not submit the project.', type: 'error' });
            console.error('Error adding project:', error);
        } finally {
            setIsLoading(false);
        }
    };

    // Handles submission for UPDATING an existing project
    const handleUpdateProject = async (e) => {
        e.preventDefault();
        setIsLoading(true);
        setUserMessage({ text: '', type: '' });

        try {
            // Ensure project_id is available for the update endpoint
            if (!editingProject || !editingProject.project_id) {
                setUserMessage({ text: 'Error: Project ID is missing for update.', type: 'error' });
                setIsLoading(false);
                return;
            }

            const response = await fetch(`http://localhost:3000/project/${editingProject.project_id}`, { 
                method: 'PUT', // Use PUT or PATCH for updates
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(editingProject) // Send the updated project data
            });
            const data = await response.json();

            if (response.ok) {
                setUserMessage({ text: data.message || 'Project updated successfully!', type: 'success' });
                handleCloseModal(); // Close modal and reset states
                fetchProjects(); // Re-fetch all projects to update the table
            } else {
                setUserMessage({ text: data.message || 'Failed to update project.', type: 'error' });
            }
        } catch (error) {
            setUserMessage({ text: 'Network error: Could not update the project.', type: 'error' });
            console.error('Error updating project:', error);
        } finally {
            setIsLoading(false);
        }
    };

    // Determine the form's submit handler based on edit mode
    const handleSubmit = editingProject ? handleUpdateProject : handleAddProject;
    // Determine the modal title
    const modalTitle = editingProject ? 'Edit Project' : 'Add New Project';
    // Determine the data object to use in the form fields
    const formData = editingProject || newProject;


    const totalProjects = projects.length;
    const completedProjects = projects.filter(p => p.status === 'Completed').length;
    const inProgressProjects = projects.filter(p => p.status === 'In Progress').length;
    const overdueProjects = projects.filter(p => new Date(p.deadline) < new Date() && p.status !== 'Completed').length;

    const statusColors = {
        'Completed': 'status-badge status-badge-completed',
        'In Progress': 'status-badge status-badge-in-progress',
        'On Hold': 'status-badge status-badge-on-hold',
        'Not Started': 'status-badge status-badge-not-started'
    };

    const priorityColors = {
        'High': 'priority-high',
        'Medium': 'priority-medium',
        'Low': 'priority-low'
    };

    return (
        <div className="projects-container">

            {/* Projects Header Section */}
            <div className="projects-header">
                <div>
                    <h1 className="projects-header h1">Projects</h1>
                    <p className="subtitle">View and manage all active projects</p>
                </div>
                <button
                    onClick={handleAddClick} // Changed to handleAddClick
                    className="new-project-btn"
                >
                    <FiPlus className="icon" />
                    New Project
                </button>
            </div>

            {/* Projects Statistics Cards Grid */}
            <div className="stats-grid">
                <div className="stat-card">
                    <div className="stat-icon stat-icon-blue">
                        <FiFolder className="stat-icon-color" />
                    </div>
                    <div>
                        <h3 className="stat-card h3">Total Projects</h3>
                        <p className="stat-value">{totalProjects}</p>
                    </div>
                </div>

                <div className="stat-card">
                    <div className="stat-icon stat-icon-green">
                        <FiCheckCircle className="stat-icon-color" />
                    </div>
                    <div>
                        <h3 className="stat-card h3">Completed</h3>
                        <p className="stat-value">{completedProjects}</p>
                    </div>
                </div>

                <div className="stat-card">
                    <div className="stat-icon stat-icon-purple">
                        <FiActivity className="stat-icon-color" />
                    </div>
                    <div>
                        <h3 className="stat-card h3">In Progress</h3>
                        <p className="stat-value">{inProgressProjects}</p>
                    </div>
                </div>

                <div className="stat-card">
                    <div className="stat-icon stat-icon-yellow">
                        <FiClock className="stat-icon-color" />
                    </div>
                    <div>
                        <h3 className="stat-card h3">Overdue</h3>
                        <p className="stat-value">{overdueProjects}</p>
                    </div>
                </div>
            </div>

            {/* Projects Table Section */}
            <div className="projects-table-container">
                <div className="table-header">
                    <h3 className="table-header h3">All Projects</h3>
                    <div className="table-actions">
                        <select className="filter-select">
                            <option>All Status</option>
                            <option>Completed</option>
                            <option>In Progress</option>
                            <option>On Hold</option>
                            <option>Not Started</option>
                        </select>
                        <input
                            type="text"
                            placeholder="Search projects..."
                            className="search-input"
                        />
                    </div>
                </div>

                {isLoading && <p className="loading-message">Loading projects...</p>}
                {userMessage.text && (
                    <div className={`user-message ${userMessage.type === 'success' ? 'user-message-success' : 'user-message-error'}`}>
                        {userMessage.text}
                    </div>
                )}
                
                <div className="table-responsive">
                    <table className="projects-table">
                        <thead>
                            <tr>
                                <th scope="col">Project Name</th>
                                <th scope="col">Status</th>
                                <th scope="col">Progress</th>
                                <th scope="col">Team</th>
                                <th scope="col">Deadline</th>
                                <th scope="col">Priority</th>
                                <th scope="col">Actions</th>
                            </tr>
                        </thead><tbody>
                            {projects.length === 0 && !isLoading ? (
                                <tr>
                                    <td colSpan="7" className="no-projects-message">
                                        No projects found. Start by adding a new one!
                                    </td>
                                </tr>
                            ) : (
                                projects.map((project) => (
                                    <tr key={project.project_id || project.id}>
                                        <td>
                                            <div className="project-name">
                                                <FiFolder className="project-icon" />
                                                <span>{project.name}</span>
                                            </div>
                                        </td>
                                        <td>
                                            <span className={`${statusColors[project.status] || 'status-badge-default'}`}>
                                                {project.status}
                                            </span>
                                        </td>
                                        <td>
                                            <div className="progress-container">
                                                <div className="progress-bar" style={{ width: `${project.progress || 0}%`, color:"red" }}></div>
                                                <span className="progress-text">{project.progress || 0}%</span>
                                            </div>
                                        </td>
                                        <td>
                                            <div className="team-members">
                                                <FiUsers className="team-icon" />
                                                {project.team_member}
                                            </div>
                                        </td>
                                        <td>{project.deadline}</td>
                                        <td className={`${priorityColors[project.priority]}`}>{project.priority}</td>
                                        <td>
                                            <button className="action-btn view">View</button>
                                            <button
                                                className="action-btn edit"
                                                onClick={() => handleEditClick(project)} // Added onClick for Edit button
                                            >
                                                Edit
                                            </button>
                                        </td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            {/* Add/Edit Project Modal (Conditionally Rendered) */}
            {showModal && (
                <div className="modal-overlay-custom" style={{ backgroundColor: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(3px)' }}>
                    <div className="modal-dialog-custom">
                        <div className="modal-content-custom">
                            <div className="modal-header-custom">
                                <h5 className="modal-title-custom">{modalTitle}</h5> {/* Dynamic Modal Title */}
                                <button type="button" className="modal-close-btn-custom" onClick={handleCloseModal} aria-label="Close">
                                    <FiX />
                                </button>
                            </div>
                            <form onSubmit={handleSubmit}> {/* Dynamic onSubmit handler */}
                                <div className="modal-body-custom">
                                    <div className="form-group-custom">
                                        <label htmlFor="name" className="form-label-custom">Project Name</label>
                                        <input
                                            type="text"
                                            id="name"
                                            name="name"
                                            value={formData.name || ''} // Use formData and handle null/undefined
                                            onChange={handleInputChange}
                                            className="form-input-custom"
                                            required
                                        />
                                    </div>
                                    <div className="form-group-custom">
                                        <label htmlFor="image" className="form-label-custom">Image URL (Optional)</label>
                                        <input
                                            type="text"
                                            id="image"
                                            name="image"
                                            value={formData.image || ''}
                                            onChange={handleInputChange}
                                            className="form-input-custom"
                                        />
                                    </div>
                                    <div className="form-group-custom">
                                        <label htmlFor="description" className="form-label-custom">Description</label>
                                        <textarea
                                            id="description"
                                            name="description"
                                            value={formData.description || ''}
                                            onChange={handleInputChange}
                                            rows="3"
                                            className="form-input-custom textarea-custom"
                                        ></textarea>
                                    </div>
                                    {/* New fields for management */}
                                    <div className="form-group-custom">
                                        <label htmlFor="status" className="form-label-custom">Status</label>
                                        <select
                                            id="status"
                                            name="status"
                                            value={formData.status || 'Not Started'} // Default value if not set
                                            onChange={handleInputChange}
                                            className="form-input-custom"
                                            required
                                        >
                                            {statusOptions.map(option => (
                                                <option key={option} value={option}>{option}</option>
                                            ))}
                                        </select>
                                    </div>
                                    <div className="form-group-custom">
                                        <label htmlFor="progress" className="form-label-custom">Progress (%)</label>
                                        <input
                                            type="number"
                                            id="progress"
                                            name="progress"
                                            value={formData.progress || 0}
                                            onChange={handleInputChange}
                                            className="form-input-custom"
                                            min="0"
                                            max="100"
                                            required
                                        />
                                    </div>
                                    <div className="form-group-custom">
                                        <label htmlFor="team" className="form-label-custom">Team Members</label>
                                        <input
                                            type="number"
                                            id="team"
                                            name="team"
                                            value={formData.team || 1}
                                            onChange={handleInputChange}
                                            className="form-input-custom"
                                            min="1"
                                            required
                                        />
                                    </div>
                                    <div className="form-group-custom">
                                        <label htmlFor="deadline" className="form-label-custom">Deadline</label>
                                        <input
                                            type="date"
                                            id="deadline"
                                            name="deadline"
                                            // Format date for input type="date"
                                            value={formData.deadline ? formData.deadline.split('T')[0] : ''}
                                            onChange={handleInputChange}
                                            className="form-input-custom"
                                        />
                                    </div>
                                    <div className="form-group-custom">
                                        <label htmlFor="priority" className="form-label-custom">Priority</label>
                                        <select
                                            id="priority"
                                            name="priority"
                                            value={formData.priority || 'Medium'} // Default value
                                            onChange={handleInputChange}
                                            className="form-input-custom"
                                            required
                                        >
                                            {priorityOptions.map(option => (
                                                <option key={option} value={option}>{option}</option>
                                            ))}
                                        </select>
                                    </div>

                                    {/* Placeholder for created_by - usually managed by auth */}
                                    <div className="form-group-custom">
                                        <label htmlFor="created_by" className="form-label-custom">Created By (Placeholder)</label>
                                        <input
                                            type="text"
                                            id="created_by"
                                            name="created_by"
                                            value={formData.created_by || '2'}
                                            onChange={handleInputChange}
                                            className="form-input-custom"
                                            required
                                            disabled // Keep disabled as it's a placeholder
                                        />
                                    </div>

                                    {isLoading && <p className="loading-message-modal">Saving project...</p>}
                                    {userMessage.text && (
                                        <div className={`user-message-modal ${userMessage.type === 'success' ? 'user-message-success' : 'user-message-error'}`}>
                                            {userMessage.text}
                                        </div>
                                    )}
                                </div>
                                <div className="modal-footer-custom">
                                    <button
                                        type="submit"
                                        className="btn-primary-custom"
                                        disabled={isLoading}
                                    >
                                        {editingProject ? 'Update Project' : 'Add Project'} {/* Dynamic button text */}
                                    </button>
                                    <button
                                        type="button"
                                        className="btn-secondary-custom"
                                        onClick={handleCloseModal} // Changed to handleCloseModal
                                    >
                                        Cancel
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Projects;
