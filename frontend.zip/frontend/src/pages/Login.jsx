import { useState, useEffect } from 'react';
import { useGoogleLogin } from '@react-oauth/google';
import { FcGoogle } from 'react-icons/fc';
import { AiOutlineEye, AiOutlineEyeInvisible } from 'react-icons/ai';
import axios from 'axios';
import './Login.css';

const Login = ({ onLoginSuccess }) => {
  const [mode, setMode] = useState('login');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false)
  // Email login
  const handleEmailLogin = async (e) => {
    e.preventDefault();
    const email = e.target.email.value;
    const password = e.target.password.value;

    try {
      const res = await fetch('http://localhost:3000/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),

      });

      const data = await res.json();
      console.log("Full response from backend:", data); // Debug line
      console.log("data.success:", data.success);       // Debug line

      if (data.success) {
        alert(data.message);
        localStorage.setItem('token', data.token);        // Save token securely
        localStorage.setItem('user', JSON.stringify(data.user));
        if (onLoginSuccess) onLoginSuccess(); // Trigger parent logic 

      } else {
        alert(data.message);
        console.log(data.message);
      }

    } catch (err) {
      console.error('Login failed:', err);
      alert('Server error. Try again later.');
    }
  };

  // Email registration
  const handleRegister = async (e) => {
    e.preventDefault();
    const name = e.target.name.value;
    const email = e.target.email.value;
    const password = e.target.password.value;
    const confirmPassword = e.target.confirmPassword.value;

    if (password !== confirmPassword) {
      return alert('Passwords do not match');
    }

    if (password.length < 6) {
      return alert('Password must be at least 6 characters long');
    }

    try {
      const res = await fetch('http://localhost:3000/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password }),
      });

      const data = await res.json();
      alert(data.message);
      setMode('login'); // Return to login
    } catch (err) {
      alert('Registration failed. Please try again.');
    }
  };
  // forget password
  const ForgotPassword = async (e) => {
    e.preventDefault();
    const name = e.target.name.value;
    const email = e.target.email.value;
    const password = e.target.password.value;

    setIsLoading(true);

    try {
      const res = await fetch('http://localhost:3000/auth/forget', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password }),
      });

      const data = await res.json();
      setIsLoading(false);

      if (data.success) {
        setMode('reset');
      } else {
        alert(data.message);
      }
    } catch (err) {
      setIsLoading(false);
      alert('Verification failed. Try again.');
    }
  };



  // Google login
  const loginWithGoogle = useGoogleLogin({
    onSuccess: async (tokenResponse) => {
      try {
        const response = await axios.post(
          `${import.meta.env.VITE_APP_BASE_URL}auth/google-login`,
          { access_token: tokenResponse.access_token }
        );
        localStorage.setItem('user', JSON.stringify(response.data.user));
        console.log('Logged in via Google:', response.data.user);
      } catch (err) {
        console.error('Google login error:', err);
      }
    },
    onError: (errorResponse) => console.error('Google login failed', errorResponse),
  });

  // Inject Google Sign-In script
  useEffect(() => {
    const script = document.createElement('script');
    script.src = 'https://accounts.google.com/gsi/client';
    script.async = true;
    script.defer = true;
    document.body.appendChild(script);

    return () => {
      document.body.removeChild(script);
    };
  }, []);

  return (
    <div className="login-container">
      <div className="login-card">
        <h2>
          {mode === 'login' && 'Welcome Back'}
          {mode === 'register' && 'Create Account'}
          {mode === 'forgot' && 'Reset Password'}
        </h2>
        {isLoading && <div className="loading">Sending reset link...</div>}

        {/* Register or Login */}
        {mode === 'login' && (
          <form onSubmit={handleEmailLogin}>
            <input type="email" name="email" placeholder="Email Address" required />
            <div className="password-input">
              <input
                type={showPassword ? 'text' : 'password'}
                name="password"
                placeholder="Password"
                required
              />
              <span
                className="toggle-password"
                onClick={() => setShowPassword(!showPassword)}
                title={showPassword ? 'Hide Password' : 'Show Password'}
              >
                {showPassword ? <AiOutlineEyeInvisible /> : <AiOutlineEye />}
              </span>
            </div>
            <div className="switch-mode">
              <button type="button" className="link-button" onClick={() => setMode('forgot')}>
                Forgot Password?
              </button>
            </div>
            <button type="submit" className="submit-btn">Login</button>
            <div className="switch-mode">
              Don't have an account? <button type="button" onClick={() => setMode('register')}>Register</button>
            </div>
          </form>
        )}

        {mode === 'register' && (
          <form onSubmit={handleRegister}>
            <input type="text" name="name" placeholder="Full Name" required />
            <input type="email" name="email" placeholder="Email Address" required />
            <div className="password-input">
              <input
                type={showPassword ? 'text' : 'password'}
                name="password"
                placeholder="New Password"
                required
              />
              <span
                className="toggle-password"
                onClick={() => setShowPassword(!showPassword)}
                title={showPassword ? 'Hide Password' : 'Show Password'}
              >
                {showPassword ? <AiOutlineEyeInvisible /> : <AiOutlineEye />}
              </span>
            </div>
            <input
              type={showPassword ? 'text' : 'password'}
              name="confirmPassword"
              placeholder="Confirm Password"
              required
            />
            <button type="submit" className="submit-btn">Register</button>
            <div className="switch-mode">
              Already have an account? <button type="button" onClick={() => setMode('login')}>Login</button>
            </div>
          </form>
        )}

        {mode === 'forgot' && (
          <form onSubmit={ForgotPassword}>
            <input type="text" name="name" placeholder='Enter your full name ' required />
            <input type="email" name="email" placeholder="Enter your registered email" required />
            <div className="password-input">
              <input
                type={showPassword ? 'text' : 'password'}
                name="password"
                placeholder="Create new Password"
                required
              />
              <span
                className="toggle-password"
                onClick={() => setShowPassword(!showPassword)}
                title={showPassword ? 'Hide Password' : 'Show Password'}
              >
                {showPassword ? <AiOutlineEyeInvisible /> : <AiOutlineEye />}
              </span>
            </div>
            <button type="submit" className="submit-btn">Send Reset Link</button>
            <div className="switch-mode">
              Remembered your password? <button type="button" onClick={() => setMode('login')}>Back to Login</button>
            </div>
          </form>
        )}

        {mode === 'reset' && (
          <form >
            <div className=''>
              Password update successfully.
            </div>
            <div className="switch-mode">
              <button type="button" onClick={() => setMode('login')}>Back to Login</button>
            </div>
          </form>
        )}

        <hr />
        <button
          className="btn btn-outline-secondary w-100 mb-3 d-flex align-items-center justify-content-center py-2"
          onClick={loginWithGoogle}
        >
          <FcGoogle size={20} className="me-2" />
          Continue with Google
        </button>
      </div>
    </div>
  );
};

export default Login;
