import React, { useState } from 'react';
import { 
  FiMessageSquare, 
  FiStar, 
  FiFilter, 
  FiSearch, 
  FiChevronDown, 
  FiMail,
  FiCheck,
  FiX,
  FiRefreshCw
} from 'react-icons/fi';
import "./Feedback.css";

const Feedback = () => {
  const [activeFilter, setActiveFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFeedback, setSelectedFeedback] = useState(null);
  const [responseText, setResponseText] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Sample feedback data
  const feedbackItems = [
    {
      id: 1,
      user: {
        name: 'Sarah Johnson',
        email: 'sarah@example.com',
        avatar: 'https://randomuser.me/api/portraits/women/44.jpg'
      },
      rating: 5,
      message: 'The dashboard is incredibly intuitive and has helped our team become much more productive. The analytics features are particularly useful!',
      date: '2023-06-15',
      status: 'new',
      category: 'feature'
    },
    {
      id: 2,
      user: {
        name: 'Michael Chen',
        email: 'michael@example.com',
        avatar: 'https://randomuser.me/api/portraits/men/32.jpg'
      },
      rating: 3,
      message: 'Overall good experience, but the reporting feature could use some improvements. It takes too many clicks to generate simple reports.',
      date: '2023-06-14',
      status: 'pending',
      category: 'improvement'
    },
    {
      id: 3,
      user: {
        name: 'Emma Davis',
        email: 'emma@example.com',
        avatar: 'https://randomuser.me/api/portraits/women/68.jpg'
      },
      rating: 1,
      message: 'Very disappointed with the mobile experience. The app crashes frequently and many features are missing compared to the desktop version.',
      date: '2023-06-12',
      status: 'responded',
      category: 'bug'
    },
    {
      id: 4,
      user: {
        name: 'David Wilson',
        email: 'david@example.com',
        avatar: 'https://randomuser.me/api/portraits/men/75.jpg'
      },
      rating: 4,
      message: 'Great product! The customer support team was very helpful when I had questions about the API integration.',
      date: '2023-06-10',
      status: 'archived',
      category: 'support'
    },
    {
      id: 5,
      user: {
        name: 'Jessica Lee',
        email: 'jessica@example.com',
        avatar: 'https://randomuser.me/api/portraits/women/25.jpg'
      },
      rating: 2,
      message: 'The onboarding process was confusing. We lost several team members who couldn\'t figure out how to use the basic features.',
      date: '2023-06-08',
      status: 'pending',
      category: 'onboarding'
    }
  ];

  // Filter feedback based on active filter and search query
  const filteredFeedback = feedbackItems.filter(item => {
    const matchesFilter = activeFilter === 'all' || item.status === activeFilter;
    const matchesSearch = item.message.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         item.user.name.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const handleRespond = () => {
    if (!responseText.trim()) return;
    
    setIsSubmitting(true);
    // In a real app, you would send the response to your backend here
    console.log('Response sent:', responseText);
    
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      setResponseText('');
      setSelectedFeedback(null);
      // Update the feedback status in your state management
    }, 1000);
  };

  const renderStars = (rating) => {
    return Array(5).fill(0).map((_, i) => (
      <FiStar 
        key={i} 
        className={`star ${i < rating ? 'filled' : ''}`} 
      />
    ));
  };

  const getStatusColor = (status) => {
    switch(status) {
      case 'new': return 'bg-blue-100 text-blue-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'responded': return 'bg-green-100 text-green-800';
      case 'archived': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getCategoryColor = (category) => {
    switch(category) {
      case 'feature': return 'bg-purple-100 text-purple-800';
      case 'improvement': return 'bg-indigo-100 text-indigo-800';
      case 'bug': return 'bg-red-100 text-red-800';
      case 'support': return 'bg-blue-100 text-blue-800';
      case 'onboarding': return 'bg-teal-100 text-teal-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="feedback-container">
      <div className="feedback-header">
        <div>
          <h1>Customer Feedback</h1>
          <p className="subtitle">View and respond to user feedback</p>
        </div>
        <div className="controls">
          <div className="search-bar">
            <FiSearch className="search-icon" />
            <input 
              type="text" 
              placeholder="Search feedback..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <button className="refresh-button">
            <FiRefreshCw />
          </button>
        </div>
      </div>

      <div className="feedback-content">
        {/* Feedback List */}
        <div className={`feedback-list ${selectedFeedback ? 'hidden' : ''}`}>
          <div className="list-header">
            <div className="filter-tabs">
              <button 
                className={`tab ${activeFilter === 'all' ? 'active' : ''}`}
                onClick={() => setActiveFilter('all')}
              >
                All
              </button>
              <button 
                className={`tab ${activeFilter === 'new' ? 'active' : ''}`}
                onClick={() => setActiveFilter('new')}
              >
                New
              </button>
              <button 
                className={`tab ${activeFilter === 'pending' ? 'active' : ''}`}
                onClick={() => setActiveFilter('pending')}
              >
                Pending
              </button>
              <button 
                className={`tab ${activeFilter === 'responded' ? 'active' : ''}`}
                onClick={() => setActiveFilter('responded')}
              >
                Responded
              </button>
              <button 
                className={`tab ${activeFilter === 'archived' ? 'active' : ''}`}
                onClick={() => setActiveFilter('archived')}
              >
                Archived
              </button>
            </div>
            <div className="sort-filter">
              <FiFilter className="filter-icon" />
              <span>Sort by: Newest</span>
              <FiChevronDown className="chevron" />
            </div>
          </div>

          <div className="feedback-items">
            {filteredFeedback.length > 0 ? (
              filteredFeedback.map(item => (
                <div 
                  key={item.id} 
                  className="feedback-item"
                  onClick={() => setSelectedFeedback(item)}
                >
                  <div className="feedback-user-info">
                    <img src={item.user.avatar} alt={item.user.name} className="feedback-avatar" />
                    <div>
                      <h3>{item.user.name}</h3>
                      <p className="email">{item.user.email}</p>
                    </div>
                  </div>
                  <div className="rating">
                    {renderStars(item.rating)}
                  </div>
                  <p className="message">{item.message}</p>
                  <div className="meta">
                    <span className={`status ${getStatusColor(item.status)}`}>
                      {item.status.charAt(0).toUpperCase() + item.status.slice(1)}
                    </span>
                    <span className={`category ${getCategoryColor(item.category)}`}>
                      {item.category.charAt(0).toUpperCase() + item.category.slice(1)}
                    </span>
                    <span className="date">{item.date}</span>
                  </div>
                </div>
              ))
            ) : (
              <div className="empty-state">
                <FiMessageSquare className="empty-icon" />
                <p>No feedback found matching your criteria</p>
              </div>
            )}
          </div>
        </div>

        {/* Feedback Detail View */}
        {selectedFeedback && (
          <div className="feedback-detail">
            <button 
              className="back-button"
              onClick={() => setSelectedFeedback(null)}
            >
              <FiChevronDown className="back-icon" />
              Back to list
            </button>
            
            <div className="detail-header">
              <div className="user-info">
                <img src={selectedFeedback.user.avatar} alt={selectedFeedback.user.name} className="avatar" />
                <div>
                  <h2>{selectedFeedback.user.name}</h2>
                  <p className="email">{selectedFeedback.user.email}</p>
                </div>
              </div>
              <div className="meta">
                <div className="rating">
                  {renderStars(selectedFeedback.rating)}
                </div>
                <span className={`status ${getStatusColor(selectedFeedback.status)}`}>
                  {selectedFeedback.status.charAt(0).toUpperCase() + selectedFeedback.status.slice(1)}
                </span>
                <span className={`category ${getCategoryColor(selectedFeedback.category)}`}>
                  {selectedFeedback.category.charAt(0).toUpperCase() + selectedFeedback.category.slice(1)}
                </span>
                <span className="date">{selectedFeedback.date}</span>
              </div>
            </div>
            
            <div className="feedback-message">
              <h3>Feedback</h3>
              <p>{selectedFeedback.message}</p>
            </div>
            
            <div className="response-section">
              <h3>Your Response</h3>
              <textarea
                placeholder="Type your response here..."
                value={responseText}
                onChange={(e) => setResponseText(e.target.value)}
                rows="5"
              ></textarea>
              <div className="response-actions">
                <button 
                  className="send-button"
                  onClick={handleRespond}
                  disabled={isSubmitting || !responseText.trim()}
                >
                  {isSubmitting ? 'Sending...' : 'Send Response'}
                </button>
                <button 
                  className="archive-button"
                  onClick={() => console.log('Archived feedback', selectedFeedback.id)}
                >
                  Archive
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Feedback;