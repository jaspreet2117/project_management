import React, { useRef, useEffect, useState } from 'react';
import {
  FiTrendingUp,
  FiUsers,
  FiDollarSign,
  FiActivity,
  FiCalendar,
  FiPieChart,
  FiBarChart2,
  FiDownload,
  FiTrendingDown // Added for 'down' trend icon in stats
} from 'react-icons/fi';
import { Chart, registerables } from 'chart.js';
import "./Analytics.css";

// Register Chart.js components
Chart.register(...registerables);

const Analytics = () => {
  const Project_completedChartRef = useRef(null);
  const trafficChartRef = useRef(null);
  const conversionChartRef = useRef(null);
  const pieChartRef = useRef(null);

  // State to hold dynamically fetched projects
  const [projects, setProjects] = useState([]);
  // State for managing loading status during API calls
  const [isLoading, setIsLoading] = useState(false);
  // State for displaying user messages (success/error)
  const [userMessage, setUserMessage] = useState({ text: '', type: '' });

  // Function to fetch projects from the backend API
  const fetchProjects = async () => {
    setIsLoading(true);
    setUserMessage({ text: '', type: '' });
    try {
      const response = await fetch('http://localhost:3000/project/all');
      const data = await response.json();

      if (response.ok) {
        setProjects(data);
      } else {
        setUserMessage({ text: data.message || 'Failed to fetch projects.', type: 'error' });
      }
    } catch (error) {
      setUserMessage({ text: 'Network error: Could not connect to the server.', type: 'error' });
      console.error('Error fetching analytics projects:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // useEffect to fetch projects on component mount
  useEffect(() => {
    fetchProjects();
  }, []);

  // Calculate dynamic stats based on fetched projects
  const completedProjectsCount = projects.filter(p => p.status === 'Completed').length;
  const totalProjectsCount = projects.length;
  const activeTeamMembersCount = projects.filter(p => p.status === 'In Progress').reduce((sum, p) => sum + (Number(p.team_member) || 0), 0);

  // Dynamic stats array using calculated values
  const dynamicStats = [
    // For these, 'change' and 'trend' are now null as we don't have historical data to show a real trend
    { title: "Projects Completed ", value: `${completedProjectsCount}/${totalProjectsCount}`, change: null, icon: <FiDollarSign size={24} />, trend: null },
    { title: "Active Team Members", value: activeTeamMembersCount.toString(), change: null, icon: <FiUsers size={24} />, trend: null },
    { title: "Task Completion Rate", value: "62%", change: "12%", icon: <FiActivity size={24} />, trend: 'up' }, // Static
    { title: "Avg. Progress per Week", value: "5%", change: "-1.2%", icon: <FiCalendar size={24} />, trend: 'down' } // Static
  ];

  // Initialize charts
  useEffect(() => {
    const chartInstances = [];

    const createChart = (ref, config) => {
      if (ref.current) {
        const ctx = ref.current.getContext('2d');
        // Destroy previous instance if exists
        if (ref.current.chart) {
          ref.current.chart.destroy();
        }
        const chart = new Chart(ctx, config);
        ref.current.chart = chart; // Store chart instance on ref
        chartInstances.push(chart);
      }
    };

    // Dynamically get project names and progress for charts
    const projectNames = projects.map(p => p.name);
    const projectProgress = projects.map(p => p.progress || 0);

    // Calculate status distribution for Pie Chart
    const inProgressCount = projects.filter(p => p.status === 'In Progress').length;
    const completedCount = projects.filter(p => p.status === 'Completed').length;
    const notStartedCount = projects.filter(p => p.status === 'Not Started').length;
    const onHoldCount = projects.filter(p => p.status === 'On Hold').length;

    // Filter out categories with zero projects to avoid empty slices
    const pieLabels = [];
    const pieData = [];
    const pieColors = [];

    if (inProgressCount > 0) { pieLabels.push('In Progress'); pieData.push(inProgressCount); pieColors.push('#f59e0b'); }
    if (completedCount > 0) { pieLabels.push('Completed'); pieData.push(completedCount); pieColors.push('#10b981'); }
    if (notStartedCount > 0) { pieLabels.push('Not Started'); pieData.push(notStartedCount); pieColors.push('#6c757d'); } // Example: Grey
    if (onHoldCount > 0) { pieLabels.push('On Hold'); pieData.push(onHoldCount); pieColors.push('#ffc107'); } // Example: Yellow


    // Project Completed Chart (Line) - Now dynamic
    createChart(Project_completedChartRef, {
      type: 'line',
      data: {
        labels: projectNames, // Dynamic labels
        datasets: [{
          label: 'Completion (%)',
          data: projectProgress, // Dynamic data
          borderColor: '#4361ee',
          backgroundColor: 'rgba(67, 97, 238, 0.05)',
          borderWidth: 2,
          tension: 0.4,
          fill: true
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          y: {
            beginAtZero: true,
            grid: { drawBorder: false, color: '#e9ecef' },
            ticks: {
              callback: value => value.toLocaleString()
            }
          },
          x: { grid: { display: false, drawBorder: false } }
        }
      }
    });

    // Hours Spent per Project (Bar Chart) - Labels dynamic, data static for now
    createChart(trafficChartRef, {
      type: 'bar',
      data: {
        labels: projectNames, // Dynamic labels
        datasets: [{
          label: 'Hours Logged',
          // Static data for now, would need backend support for dynamic hours
          data: projects.map((_, index) => [45, 50, 60, 80][index] || 0), // Use existing sample data for projects
          backgroundColor: ['#4361ee', '#3f37c9', '#4895ef', '#10b981'],
        }]

      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          y: {
            beginAtZero: true,
            grid: { drawBorder: false, color: '#e9ecef' }
          },
          x: { grid: { display: false, drawBorder: false } }
        }
      }
    });

    // Task Completion Rate Chart (Line) - Remains static
    createChart(conversionChartRef, {
      type: 'line',
      data: {
        labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
        datasets: [{
          label: 'Task Completion (%)',
          data: [45, 52, 60, 68, 72, 78, 85],
          borderColor: '#10b981',
          backgroundColor: 'rgba(16, 185, 129, 0.05)',
          borderWidth: 2,
          tension: 0.4,
          fill: true
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          y: {
            beginAtZero: true,
            grid: { drawBorder: false, color: '#e9ecef' },
            ticks: {
              callback: value => value + '%'
            }
          },
          x: { grid: { display: false, drawBorder: false } }
        }
      }
    });

    // Project Status Distribution (Doughnut Chart) - Now dynamic
    if (pieChartRef.current && projects.length > 0) { // Only create if projects exist
        createChart(pieChartRef, {
            type: 'doughnut',
            data: {
                labels: pieLabels, // Dynamic labels based on actual project statuses
                datasets: [{
                    data: pieData, // Dynamic data based on project counts
                    backgroundColor: pieColors, // Dynamic colors for slices
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '70%',
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            usePointStyle: true,
                            padding: 20
                        }
                    }
                }
            }
        });
    }


    // Cleanup handler
    return () => {
      chartInstances.forEach(chart => chart.destroy());
    };
  }, [projects]); // Dependency array: re-run effect when 'projects' state changes


  return (
    <div className="analytics-container">
      <div className="analytics-header">
        <div>
          <h1>Analytics Dashboard</h1>
          <p className="subtitle">Key metrics and performance indicators</p>
        </div>
        <button className="export-btn">
          <FiDownload className="icon" />
          Export Report
        </button>
      </div>

      {/* Stats Cards */}
      <div className="stats-grid">
        {dynamicStats.map((stat, index) => (
          <div className="stat-card" key={index}>
            <div className="stat-icon" style={{ backgroundColor: stat.trend === 'up' ? '#e6f7ee' : (stat.trend === 'down' ? '#feeceb' : '#e0e0e0') }}>
              {stat.icon}
            </div>
            <div className="stat-content">
              <h3>{stat.title}</h3>
              <p className="stat-value">{stat.value}</p>
              {/* Conditional rendering for change and trend icon */}
              {stat.change && (
                <p className={`stat-change ${stat.trend}`}>
                  {stat.change} {stat.trend === 'up' && <FiTrendingUp className="trend-icon" />}
                  {stat.trend === 'down' && <FiTrendingDown className="trend-icon" />}
                </p>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Main Chart */}
      <div className="main-chart">
        <div className="chart-header">
          <h3>Project Completed</h3>
        </div>
        <div className="chart-wrapper">
          {isLoading && <p className="text-center" style={{ color: '#4361ee', paddingTop: '20px' }}>Loading chart data...</p>}
          {userMessage.type === 'error' && <p className="text-center" style={{ color: '#dc3545', paddingTop: '20px' }}>{userMessage.text}</p>}
          <canvas ref={Project_completedChartRef}></canvas>
        </div>
      </div>

      {/* Secondary Charts */}
      <div className="secondary-charts">
        <div className="chart-container">
          <div className="chart-header">
            <h3>Hours Spent per Project</h3>
            <FiBarChart2 className="chart-icon" />
          </div>
          <div className="chart-wrapper">
            {isLoading && <p className="text-center" style={{ color: '#4361ee', paddingTop: '20px' }}>Loading chart data...</p>}
            {userMessage.type === 'error' && <p className="text-center" style={{ color: '#dc3545', paddingTop: '20px' }}>{userMessage.text}</p>}
            <canvas ref={trafficChartRef}></canvas>
          </div>
        </div>

        <div className="chart-container">
          <div className="chart-header">
            <h3>Task Completion Rate</h3>
            <FiActivity className="chart-icon" />
          </div>
          <div className="chart-wrapper">
            {isLoading && <p className="text-center" style={{ color: '#4361ee', paddingTop: '20px' }}>Loading chart data...</p>}
            {userMessage.type === 'error' && <p className="text-center" style={{ color: '#dc3545', paddingTop: '20px' }}>{userMessage.text}</p>}
            <canvas ref={conversionChartRef}></canvas>
          </div>
        </div>
      </div>

      {/* Bottom Row */}
      <div className="bottom-row">
        <div className="device-chart">
          <div className="chart-header">
            <h3>Project Status Distribution</h3>
            <FiPieChart className="chart-icon" />
          </div>
          <div className="chart-wrapper">
            {isLoading && <p className="text-center" style={{ color: '#4361ee', paddingTop: '20px' }}>Loading chart data...</p>}
            {userMessage.type === 'error' && <p className="text-center" style={{ color: '#dc3545', paddingTop: '20px' }}>{userMessage.text}</p>}
            <canvas ref={pieChartRef}></canvas>
          </div>
        </div>

        <div className="top-pages">
          <h3>Top Performing Projects</h3>
          {isLoading && <p className="text-center" style={{ color: '#4361ee', paddingTop: '20px' }}>Loading projects...</p>}
          {userMessage.type === 'error' && <p className="text-center" style={{ color: '#dc3545', paddingTop: '20px' }}>{userMessage.text}</p>}
          
          {/* Conditional rendering for no projects fetched */}
          {!isLoading && projects.length === 0 && userMessage.text === '' && (
            <p className="text-center" style={{ color: '#6c757d', paddingTop: '20px' }}>No projects available to display.</p>
          )}

          <table className="pages-table">
            <thead>
              <tr>
                <th>Project</th>
                <th>Progress</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {/* Sort projects by progress in descending order before mapping */}
              {projects.sort((a, b) => (b.progress || 0) - (a.progress || 0)).map((project, index) => (
                <tr key={project.project_id || index}> {/* Use project_id for key if available, fallback to index */}
                  <td>{project.name}</td>
                  <td>{project.progress || 0}%</td>
                  <td>{project.status}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Analytics;
