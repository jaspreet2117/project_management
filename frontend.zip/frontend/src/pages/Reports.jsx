import React, { useRef, useEffect, useState } from 'react';
import {
  FiDownload,
  FiCalendar,
  FiBarChart2,
  FiPieChart,
  FiTrendingUp,
  FiRefreshCw,
  FiFile,
  
} from 'react-icons/fi';
import { Chart, registerables } from 'chart.js';
import "./Reports.css";

// Register Chart.js components
Chart.register(...registerables);

const Reports = () => {
  const [timeRange, setTimeRange] = useState('7d');
  const [isLoading, setIsLoading] = useState(false);
  const salesChartRef = useRef(null);
  const trafficChartRef = useRef(null);
  const Project_completedChartRef = useRef(null);
  const categoryChartRef = useRef(null);

  // Sample reports data
  const reports = [
    { id: 1, name: 'Monthly Sales Report', type: 'Sales', lastRun: '2023-06-15', frequency: 'Monthly' },
    { id: 2, name: 'User Activity Report', type: 'Users', lastRun: '2023-06-18', frequency: 'Weekly' },
    { id: 3, name: 'Project_completed Breakdown', type: 'Financial', lastRun: '2023-06-10', frequency: 'Monthly' },
    { id: 4, name: 'Marketing Performance', type: 'Marketing', lastRun: '2023-06-17', frequency: 'Weekly' },
    { id: 5, name: 'Annual Summary', type: 'Financial', lastRun: '2023-01-30', frequency: 'Yearly' }
  ];

  // Initialize charts
  useEffect(() => {
    const chartInstances = [];

    const createChart = (ref, config) => {
      if (ref.current) {
        const ctx = ref.current.getContext('2d');
        const chart = new Chart(ctx, config);
        chartInstances.push(chart);
      }
    };

    // Sales Chart
    createChart(salesChartRef, {
      type: 'line',
      data: {
          labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
          datasets: [{
            label: 'Task Completion (%)',
            data: [45, 52, 60, 68, 72, 78, 85],
            borderColor: '#10b981',
            backgroundColor: 'rgba(16, 185, 129, 0.05)',
            borderWidth: 2,
            tension: 0.4,
            fill: true
          }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          y: {
            beginAtZero: true,
            grid: { drawBorder: false, color: '#e9ecef' },
            ticks: {
              callback: value => value.toLocaleString()
            }
          },
          x: { grid: { display: false, drawBorder: false } }
        }
      }
    });

    // Traffic Chart
    createChart(trafficChartRef, {
      type: 'bar',
      data: {
        labels: ['Live Streaming App', 'Tour and Travels', 'Chat App', 'Recipe Finder'],
        datasets: [{
          label: 'Hours Logged',
          data: [45, 50, 60, 80],
          backgroundColor: ['#4361ee', '#3f37c9', '#4895ef', '#10b981'],
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          y: {
            beginAtZero: true,
            grid: { drawBorder: false, color: '#e9ecef' }
          },
          x: { grid: { display: false, drawBorder: false } }
        }
      }
    });

    // Project_completed Chart
    createChart(Project_completedChartRef, {
      type: 'line',
      data: {
        labels: ['Live Streaming App', 'Tour and Travels', 'Chat App', 'Recipe Finder'],
        datasets: [{
          label: 'Completion (%)',
          data: [35, 50, 60, 100], // Assuming some sample progress
          borderColor: '#4361ee',
          backgroundColor: 'rgba(67, 97, 238, 0.05)',
          borderWidth: 2,
          tension: 0.4,
          fill: true
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          y: {
            beginAtZero: true,
            grid: { drawBorder: false, color: '#e9ecef' },
            ticks: {
              callback: value => '$' + value.toLocaleString()
            }
          },
          x: { grid: { display: false, drawBorder: false } }
        }
      }
    });

    // Category Chart
    createChart(categoryChartRef, {
      type: 'doughnut',
      data: {
        labels: ['In Progress', 'Completed',],
        datasets: [{
          data: [3, 1],
          backgroundColor: ['#f59e0b', '#10b981'],
          borderWidth: 0
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '70%',
        plugins: {
          legend: {
            position: 'bottom',
            labels: { usePointStyle: true, padding: 20 }
          }
        }
      }
    });

    //  Cleanup phase to mitigate memory leaks and canvas conflicts
    return () => {
      chartInstances.forEach(chart => chart.destroy());
    };
  }, [timeRange]);


  const handleRefresh = () => {
    setIsLoading(true);
    // Simulate data refresh
    setTimeout(() => {
      setIsLoading(false);
    }, 1000);
  };

  const handleExport = (reportId) => {
    console.log(`Exporting report ${reportId}`);
    // In a real app, this would trigger a download
  };

  return (
    <div className="reports-container">
      <div className="reports-header">
        <div>
          <h1>Reports Dashboard</h1>
          <p className="subtitle">Analyze and export your business data</p>
        </div>
        <div className="controls">
          <div className="time-filter">
            <FiCalendar className="filter-icon" />
            <select
              value={timeRange}
              onChange={(e) => setTimeRange(e.target.value)}
            >
              <option value="7d">Last 7 days</option>
              <option value="30d">Last 30 days</option>
              <option value="90d">Last quarter</option>
              <option value="12m">Last year</option>
            </select>
          </div>
          <button
            className="refresh-button"
            onClick={handleRefresh}
            disabled={isLoading}
          >
            <FiRefreshCw className={`refresh-icon ${isLoading ? 'spin' : ''}`} />
            Refresh
          </button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="summary-cards">
        <div className="summary-card">
          <div className="card-content">
            <h3>Total Project_completed</h3>
            <p className="value">1</p>
            <p className="change positive">
              <FiTrendingUp /> 3 inprogress 
            </p>
          </div>
          <div className="card-icon">
          <FiFile/>
          </div>
        </div>

        <div className="summary-card">
          <div className="card-content">
            <h3>Total projects</h3>
            <p className="value">4</p>
            <p className="change positive">
              <FiTrendingUp /> 1 Completed
            </p>
          </div>
          <div className="card-icon">
            <FiBarChart2 />
          </div>
        </div>

        <div className="summary-card">
          <div className="card-content">
            <h3>Avg working hour</h3>
            <p className="value">9 Hours</p>
            <p className="change negative">
              <FiTrendingUp />  1 Hour increases
            </p>
          </div>
          <div className="card-icon">
            <FiPieChart />
          </div>
        </div>
      </div>

      {/* Main Charts */}
      <div className="chart-row">
        <div className="chart-container">
          <div className="chart-header">
            <h3>Sales Overview</h3>
            <button className="export-btn">
              <FiDownload /> Export
            </button>
          </div>
          <div className="chart-wrapper">
            <canvas ref={salesChartRef}></canvas>
          </div>
        </div>

        <div className="chart-container">
          <div className="chart-header">
            <h3>Traffic Sources</h3>
            <button className="export-btn">
              <FiDownload /> Export
            </button>
          </div>
          <div className="chart-wrapper">
            <canvas ref={trafficChartRef}></canvas>
          </div>
        </div>
      </div>

      {/* Secondary Charts */}
      <div className="chart-row">
        <div className="chart-container">
          <div className="chart-header">
            <h3>Daily Project_completed</h3>
            <button className="export-btn">
              <FiDownload /> Export
            </button>
          </div>
          <div className="chart-wrapper">
            <canvas ref={Project_completedChartRef}></canvas>
          </div>
        </div>

        <div className="chart-container">
          <div className="chart-header">
            <h3>Sales by Category</h3>
            <button className="export-btn">
              <FiDownload /> Export
            </button>
          </div>
          <div className="chart-wrapper">
            <canvas ref={categoryChartRef}></canvas>
          </div>
        </div>
      </div>

      {/* Saved Reports Table */}
      {/* <div className="saved-reports">
        <div className="section-header">
          <h2>Saved Reports</h2>
          <button className="create-report-btn">
            + Create New Report
          </button>
        </div>

        <div className="reports-table">
          <table>
            <thead>
              <tr>
                <th>Report Name</th>
                <th>Type</th>
                <th>Last Run</th>
                <th>Frequency</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {reports.map(report => (
                <tr key={report.id}>
                  <td>{report.name}</td>
                  <td>
                    <span className={`report-type ${report.type.toLowerCase()}`}>
                      {report.type}
                    </span>
                  </td>
                  <td>{report.lastRun}</td>
                  <td>{report.frequency}</td>
                  <td>
                    <button
                      className="action-butn view"
                      onClick={() => console.log(`Viewing report ${report.id}`)}
                    >
                      View
                    </button>
                    <button
                      className="action-butn export"
                      onClick={() => handleExport(report.id)}
                    >
                      <FiDownload /> Export
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div> */}
    </div>
  );
};

export default Reports;