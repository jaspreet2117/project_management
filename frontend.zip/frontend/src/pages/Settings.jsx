import React, { useState } from 'react';
import {
  FiUser,
  FiLock,
  FiBell,
  FiMail,
  FiGlobe,
  FiCreditCard,
  FiShield,
  FiSave,
  FiMoon,
  FiSun
} from 'react-icons/fi';
import "./Settings.css";

const Settings = () => {
  const [activeTab, setActiveTab] = useState('account');
  const [darkMode, setDarkMode] = useState(false);
  const [formData, setFormData] = useState({
    name: 'John Doe',
    email: 'john.doe@example.com',
    phone: '+1 (555) 123-4567',
    language: 'en',
    notifications: true,
    newsletter: true,
    twoFactor: false
  });

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // In a real app, you would save the settings to your backend here
    console.log('Settings saved:', formData);
  };

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
    // In a real app, you would apply the dark mode theme here
    console.log('Dark mode:', !darkMode);
  };

  return (
    <div className={`settings-container ${darkMode ? 'dark' : ''}`}>
      <div className="settings-header">
        <h1>Settings</h1>
        <button
          className="dark-mode-toggle"
          onClick={toggleDarkMode}
        >
          {darkMode ? <FiSun /> : <FiMoon />}
          {darkMode ? 'Light Mode' : 'Dark Mode'}
        </button>
      </div>

      <div className="settings-content">
        <div className="settings-sidebar">
          <div
            className={`sidebar-item ${activeTab === 'account' ? 'active' : ''}`}
            onClick={() => setActiveTab('account')}
          >
            <FiUser className="icon" />
            <span>Account</span>
          </div>
          <div
            className={`sidebar-item ${activeTab === 'security' ? 'active' : ''}`}
            onClick={() => setActiveTab('security')}
          >
            <FiLock className="icon" />
            <span>Security</span>
          </div>

          {/* <div 
            className={`sidebar-item ${activeTab === 'notifications' ? 'active' : ''}`}
            onClick={() => setActiveTab('notifications')}
          >
          <FiBell className="icon" />
            <span>Notifications</span>
          </div> */}
          {/* {/* <div 
            className={`sidebar-item ${activeTab === 'billing' ? 'active' : ''}`}
            onClick={() => setActiveTab('billing')}
          >
            {/* <FiCreditCard className="icon" />
            <span>Billing</span>
          </div> */}
          {/* <div 
            className={`sidebar-item ${activeTab === 'privacy' ? 'active' : ''}`}
            onClick={() => setActiveTab('privacy')}
          > 
            <FiShield className="icon" />
            <span>Privacy</span>
          </div> */}
        </div>

        <div className="settings-main">
          {activeTab === 'account' && (
            <form onSubmit={handleSubmit}>
              <h2 className="section-title">
                <FiUser className="title-icon" />
                Account Settings
              </h2>

              <div className="form-group">
                <label htmlFor="name">Full Name</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                />
              </div>

              <div className="form-group">
                <label htmlFor="email">Email Address</label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                />
              </div>

              <div className="form-group">
                <label htmlFor="phone">Phone Number</label>
                <input
                  type="tel"
                  id="phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handleInputChange}
                />
                {/* Google Translate element styled like other items */}
                <div className="menu-item">
                  <span className="menu-icon"><FiGlobe size={18} /></span>
                 
                    <span className="menu-text">
                      <div id="google_translate_element"></div>
                    </span>
                </div>

              </div>

              {/* <div className="form-group">
                <label htmlFor="language">Language</label>
                <select
                  id="language"
                  name="language"
                  value={formData.language}
                  onChange={handleInputChange}
                >
                  <option value="en">English</option>
                  <option value="es">Spanish</option>
                  <option value="fr">French</option>
                  <option value="de">German</option>
                  <option value="ja">Japanese</option>
                </select>
              </div> */}

              <button type="submit" className="save-button">
                <FiSave className="icon" />
                Save Changes
              </button>
            </form>
          )}

          {activeTab === 'security' && (
            <form onSubmit={handleSubmit}>
              <h2 className="section-title">
                <FiLock className="title-icon" />
                Security Settings
              </h2>

              <div className="form-group checkbox-group">
                <input
                  type="checkbox"
                  id="twoFactor"
                  name="twoFactor"
                  checked={formData.twoFactor}
                  onChange={handleInputChange}
                />
                <label htmlFor="twoFactor">Enable Two-Factor Authentication</label>
              </div>

              <div className="form-group">
                <label>Password</label>
                <button type="button" className="change-password-button">
                  Change Password
                </button>
              </div>

              <div className="form-group">
                <label>Active Sessions</label>
                <div className="sessions-list">
                  <div className="session-item">
                    <div>
                      <strong>Chrome on Windows</strong>
                      <span>New York, USA</span>
                    </div>
                    <button className="revoke-button">Revoke</button>
                  </div>
                  <div className="session-item">
                    <div>
                      <strong>Safari on iPhone</strong>
                      <span>San Francisco, USA</span>
                    </div>
                    <button className="revoke-button">Revoke</button>
                  </div>
                </div>
              </div>
            </form>
          )}

          {/* {activeTab === 'notifications' && (
            <form onSubmit={handleSubmit}>
              <h2 className="section-title">
                <FiBell className="title-icon" />
                Notification Settings
              </h2>
              
              <div className="form-group checkbox-group">
                <input
                  type="checkbox"
                  id="notifications"
                  name="notifications"
                  checked={formData.notifications}
                  onChange={handleInputChange}
                />
                <label htmlFor="notifications">Enable Notifications</label>
              </div>
              
              <div className="form-group checkbox-group">
                <input
                  type="checkbox"
                  id="newsletter"
                  name="newsletter"
                  checked={formData.newsletter}
                  onChange={handleInputChange}
                />
                <label htmlFor="newsletter">Receive Newsletter</label>
              </div>
              
              <h3 className="subsection-title">Notification Preferences</h3>
              
              <div className="preferences-grid">
                <div className="preference-item">
                  <h4>Email Notifications</h4>
                  <div className="checkbox-group">
                    <input type="checkbox" id="email-mentions" defaultChecked />
                    <label htmlFor="email-mentions">Mentions</label>
                  </div>
                  <div className="checkbox-group">
                    <input type="checkbox" id="email-comments" defaultChecked />
                    <label htmlFor="email-comments">Comments</label>
                  </div>
                </div>
                
                <div className="preference-item">
                  <h4>Push Notifications</h4>
                  <div className="checkbox-group">
                    <input type="checkbox" id="push-mentions" defaultChecked />
                    <label htmlFor="push-mentions">Mentions</label>
                  </div>
                  <div className="checkbox-group">
                    <input type="checkbox" id="push-comments" />
                    <label htmlFor="push-comments">Comments</label>
                  </div>
                </div>
              </div>
              
              <button type="submit" className="save-button">
                <FiSave className="icon" />
                Save Changes
              </button>
            </form>
          )} */}

          {/* {activeTab === 'privacy' && (
            <form onSubmit={handleSubmit}>
              <h2 className="section-title">
                <FiShield className="title-icon" />
                Privacy Settings
              </h2>
              
              <div className="form-group">
                <label>Data Sharing</label>
                <div className="radio-group">
                  <input type="radio" id="share-all" name="data-sharing" defaultChecked />
                  <label htmlFor="share-all">Share data with trusted partners</label>
                </div>
                <div className="radio-group">
                  <input type="radio" id="share-limited" name="data-sharing" />
                  <label htmlFor="share-limited">Share limited data only</label>
                </div>
                <div className="radio-group">
                  <input type="radio" id="share-none" name="data-sharing" />
                  <label htmlFor="share-none">Don't share any data</label>
                </div>
              </div>
              
              <div className="form-group">
                <label>Profile Visibility</label>
                <select>
                  <option>Public</option>
                  <option>Friends Only</option>
                  <option>Private</option>
                </select>
              </div>
              
              <div className="form-group checkbox-group">
                <input type="checkbox" id="analytics" defaultChecked />
                <label htmlFor="analytics">Allow analytics tracking</label>
              </div>
              
              <div className="form-group checkbox-group">
                <input type="checkbox" id="personalized-ads" defaultChecked />
                <label htmlFor="personalized-ads">Personalized advertisements</label>
              </div>
              
              <div className="danger-zone">
                <h3 className="danger-title">Danger Zone</h3>
                <p className="danger-description">
                  These actions are irreversible. Please proceed with caution.
                </p>
                <button type="button" className="delete-account-button">
                  Delete Account
                </button>
              </div>
              
              <button type="submit" className="save-button">
                <FiSave className="icon" />
                Save Changes
              </button>
            </form>
          )} */}
        </div>
      </div>
    </div>
  );
};

export default Settings;