import { createBrowserRouter } from 'react-router-dom';
import App from './App';
import Dashboard from './pages/Dashboard';
import Projects from './pages/Projects';
import Team from './pages/Team';
import Analytics from './pages/Analytics';
import Messages from './pages/Messages';
import Settings from './pages/Settings';
import Reports from './pages/Reports';
import Feedback from './pages/Feedback';

export const router = createBrowserRouter([
  {
    path: '/',
    element: <App />,
    children: [
      {
        path: '/',
        element: <Dashboard />,
      },
      {
        path: '/projects',
        element: <Projects />,
      },
      {
        path: '/team',
        element: <Team />,
      },
      {
        path: '/analytics',
        element: <Analytics />,
      },
      {
        path: '/messages',
        element: <Messages />,
      },
      {
        path: '/settings',
        element: <Settings />,
      },
      {
        path: '/reports',
        element: <Reports />,
      },
      {
        path: '/feedback',
        element: <Feedback />,
      },
    ],
  },
]);