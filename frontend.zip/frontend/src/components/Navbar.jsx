import UserDropdown from './UserDropdown';

const Navbar = ({ toggleSidebar }) => {
  return (
    <header className="navbar-container">
      <nav className="navbar">
        <div className="navbar-brand">
          <button onClick={toggleSidebar} className="sidebar-toggle-button" aria-label="Toggle Sidebar">
            <svg viewBox="0 0 24 24" focusable="false" aria-hidden="true" className="button_svg" width="24" height="24">
              <path xmlns="http://www.w3.org/2000/svg" fillRule="evenodd" clipRule="evenodd" d="M19 4C19.5523 4 20 3.55229 20 3C20 2.44772 19.5523 2 19 2L3 2C2.44772 2 2 2.44772 2 3C2 3.55228 2.44772 4 3 4L19 4ZM20.47 7.95628L15.3568 11.152C14.7301 11.5437 14.7301 12.4564 15.3568 12.848L20.47 16.0438C21.136 16.4601 22 15.9812 22 15.1958V8.80427C22 8.01884 21.136 7.54 20.47 7.95628ZM11 13C11.5523 13 12 12.5523 12 12C12 11.4477 11.5523 11 11 11L3 11C2.44771 11 2 11.4477 2 12C2 12.5523 2.44771 13 3 13L11 13ZM20 21C20 21.5523 19.5523 22 19 22L3 22C2.44771 22 2 21.5523 2 21C2 20.4477 2.44771 20 3 20L19 20C19.5523 20 20 20.4477 20 21Z"></path>
            </svg>
          </button>
          <span className="app-name">Project</span>
        </div>
        <div className="navbar-actions">
          <UserDropdown />
        </div>
      </nav>
    </header>
  );
};

export default Navbar;