import {
  FiHome,
  FiFolder,
  FiUsers,
  FiPieChart,
  FiMessageSquare,
  FiSettings,
  FiFileText,
  FiMessageCircle,
  FiGlobe
} from 'react-icons/fi';
import { NavLink } from 'react-router-dom';
import { SiNginxproxymanager } from "react-icons/si";

const Sidebar = ({ collapsed }) => {
  const menuItems = [
    { name: 'Dashboard', icon: <FiHome size={18} />, path: '/' },
    { name: 'Projects', icon: <FiFolder size={18} />, path: '/projects' },
    { name: 'Team', icon: <FiUsers size={18} />, path: '/team' },
    { name: 'Analytics', icon: <FiPieChart size={18} />, path: '/analytics' },
    { name: 'Messages', icon: <FiMessageSquare size={18} />, path: '/messages' },
    { name: 'Settings', icon: <FiSettings size={18} />, path: '/settings' },
    { name: 'Reports', icon: <FiFileText size={18} />, path: '/reports' },
    { name: 'Feedback', icon: <FiMessageCircle size={18} />, path: '/feedback' }
  ];

  return (
    <aside className={`sidebar ${collapsed ? 'collapsed' : ''}`}>
      <div className="sidebar-header d-flex items-center gap-1">
        <SiNginxproxymanager className="company-logo" />
      </div>
      <nav className="sidebar-menu">
        {menuItems.map((item, index) => (
          <NavLink key={index} to={item.path}>
            {({ isActive }) => (
              <div className={`menu-item ${isActive ? 'active' : ''}`}>
                <span className="menu-icon">{item.icon}</span>
                {!collapsed && <span className="menu-text">{item.name}</span>}
                {isActive && <span className="active-indicator"></span>}
              </div>
            )}
          </NavLink>
        ))}

       
      </nav>
    </aside>
  );
};

export default Sidebar;
