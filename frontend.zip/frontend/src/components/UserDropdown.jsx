import { useState, useRef, useEffect } from 'react';
import { FiChevronDown } from 'react-icons/fi';
import { IoPersonCircleSharp, IoSettingsOutline, IoLogOutOutline, IoNotificationsOutline } from "react-icons/io5";


const UserDropdown = () => {
    const [isOpen, setIsOpen] = useState(false);
    const dropdownRef = useRef(null);

    const toggleDropdown = () => setIsOpen(!isOpen);

    useEffect(() => {
        const handleClickOutside = (event) => {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
                setIsOpen(false);
            }
        };

        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    return (
        <div className="user-dropdown" ref={dropdownRef}>
            <button className="user-toggle" onClick={toggleDropdown}>
                <div className="user-avatar">
                    <IoPersonCircleSharp className="user-avatar" />
                </div>
                <div className="user-info">
                    <span className="user-name">John Doe</span>
                    <span className="user-role">Administrator</span>
                </div>
                <FiChevronDown className={`dropdown-chevron ${isOpen ? 'open' : ''}`} />
            </button>

            <div className={`dropdown-menu ${isOpen ? 'open' : ''}`}>
                <div className="dropdown-header">
                    <div className="dropdown-avatar">
                        <IoPersonCircleSharp className="user-avatar" />
                    </div>
                    <div>
                        <div className="dropdown-name">John Doe</div>
                        <div className="dropdown-email">john.doe@example.com</div>
                    </div>
                </div>
                <div className="dropdown-divider"></div>

                <div className="dropdown-item">
                    <IoSettingsOutline className="dropdown-icon" />
                    <span>Account Settings</span>
                </div>
                <div className="dropdown-item">
                    <IoLogOutOutline className="dropdown-icon" />
                    <span>Log Out</span>
                </div>
            </div>
        </div>
    );
};

export default UserDropdown;