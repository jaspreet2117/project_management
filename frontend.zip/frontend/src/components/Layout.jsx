import { useState } from 'react';
import Navbar from './Navbar';
import Sidebar from './Sidebar';

const Layout = ({ children }) => {
    const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);

    const handleToggleSidebar = () => {
        setIsSidebarCollapsed(prev => !prev);
    };

    return (
        <div className="app-layout">

            <div className="layout-body" style={{ display: 'flex', height: '100vh' }}>
                {/* Sidebar */}
                <Sidebar collapsed={isSidebarCollapsed} />

                {/* Main Content */}
                <main
                    className="main-content"
                    style={{
                        flex: 1,
                        padding: '20px',
                        backgroundColor: '#f5f7fa',
                        overflowY: 'auto',
                    }}
                >
                    {/* Navbar at the top (outside sidebar/main content flex container) */}
                    <Navbar toggleSidebar={handleToggleSidebar} />
                    <div className="content-area">
                        {children}
                    </div>
                </main>
            </div>
        </div>
    );
};

export default Layout;