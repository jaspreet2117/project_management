import { useEffect,useState } from 'react';
import Layout from './components/Layout';
import { Outlet } from 'react-router-dom';
import "./App.css";
import Login from './pages/Login';

function App() {
//  use state for login page condition 
 const [isAuthenticated, setIsAuthenticated] = useState(false);
  useEffect(() => {
    // Inject Google Translate Script
    const addGoogleTranslateScript = () => {
      if (!document.querySelector('#google-translate-script')) {
        const script = document.createElement('script');
        script.id = 'google-translate-script';
        script.src = '//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit';
        document.body.appendChild(script);
      }
    };

    // Global callback for Translate API
    window.googleTranslateElementInit = () => {
      if (window.google && window.google.translate) {
        new window.google.translate.TranslateElement(
          { pageLanguage: 'en' },
          'google_translate_element'
        );
      }
    };

    addGoogleTranslateScript();

    // Optional: Re-initialize on window resize
    const handleResize = () => {
      if (
        window.googleTranslateElementInit &&
        window.google &&
        window.google.translate
      ) {
        window.googleTranslateElementInit();
      }
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);
  return (

 <>
      {!isAuthenticated ? (
        <Login onLoginSuccess={() => setIsAuthenticated(true)} />
      ) : (
        <Layout>
          <Outlet />
        </Layout>
      )}
    </>
  );
}

export default App;